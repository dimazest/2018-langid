module OAuth
  class Error < StandardError
  end
end
