module OAuth
  module Client
  end
end
