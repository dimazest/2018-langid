# this exists for backwards-compatibility

require 'oauth/tokens/token'
require 'oauth/tokens/server_token'
require 'oauth/tokens/consumer_token'
require 'oauth/tokens/request_token'
require 'oauth/tokens/access_token'
